package chatbot;

public class ChatBotFactory {
    public ChatBot buildChatBot(ChatBotType chatBotType){
        if (chatBotType == ChatBotType.hello){
            return new HelloCB(chatBotType);
        }else if(chatBotType == ChatBotType.time){
            return new TimeCB(chatBotType);
        }else if(chatBotType == ChatBotType.icndb){
            return new IcndbCB(chatBotType);
        }else if(chatBotType == ChatBotType.quiz){
            return new QuizCB(chatBotType);
        }
        return null;
    }
}
