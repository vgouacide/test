package chatbot;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class TimeCB extends ChatBot{

    public TimeCB(ChatBotType chatBotType) {
        this.chatBotType = chatBotType;
        this.nameCB = chatBotType.name();
    }

    @Override
    public String answerTo(String message) {
        return "[" + nameCB + "] " + LocalDateTime.now().format(DateTimeFormatter.ofPattern("'Nous sommes' EEEE dd MMMM 'et il est' HH'h'mm'.'"));
    }
}
