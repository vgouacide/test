package chatbot;

public enum ChatBotType {
    hello,
    time,
    icndb,
    quiz
}
