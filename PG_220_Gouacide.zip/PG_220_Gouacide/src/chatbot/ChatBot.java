package chatbot;

public abstract class ChatBot {
    protected String nameCB;
    protected ChatBotType chatBotType;

    public boolean isTypeOf(ChatBotType chatBotType){
        if (this.chatBotType == chatBotType){
            return true;
        }else return false;
    }

    public abstract String answerTo(String message);

    public String getNameCB() {
        return nameCB;
    }

    public ChatBotType getChatBotType() {
        return chatBotType;
    }
}
