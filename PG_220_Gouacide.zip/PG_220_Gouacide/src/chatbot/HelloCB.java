package chatbot;

import chat.Chat;

public class HelloCB extends ChatBot{

    public HelloCB(ChatBotType chatBotType) {
        this.chatBotType = chatBotType;
        this.nameCB = chatBotType.name();
    }

    @Override
    public String answerTo(String message) {
        return "[" + nameCB + "] " + "Salut " + Chat.getNameUser() + "!";
    }
}
