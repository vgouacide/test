package chatbot;

import java.util.ArrayList;

public class ChatBotList {
    private static ChatBotList chatBotListInstance = null;
    private ArrayList<ChatBot> chatBotList = new ArrayList<ChatBot>();

    public ChatBotList() {
        ChatBotFactory chatBotFactory = new ChatBotFactory();
        for (ChatBotType chatBotType : ChatBotType.values()){
            chatBotList.add(chatBotFactory.buildChatBot(chatBotType));
        }
    }

    public ChatBot findChatBotWithType(String chatBotName){
        for (ChatBot chatBot : chatBotList){
            if (chatBot != null){
                if (chatBot.getNameCB().equals(chatBotName))
                    return chatBot;
            }
        }
        return null;
    }

    public static ChatBotList getInstance(){
        if(chatBotListInstance == null)
            chatBotListInstance = new ChatBotList();
        return chatBotListInstance;
    }
}
