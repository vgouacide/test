package chatbot;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import utils.JsonReader;

import java.io.IOException;
import java.util.*;

public class QuizCB extends ChatBot{

    public QuizCB(ChatBotType chatBotType) {
        this.chatBotType = chatBotType;
        this.nameCB = chatBotType.name();
    }

    @Override
    public String answerTo(String message) {
        String arg = "";
        int numberQuestions = 1;
        if (message.split(" ").length > 1){
            arg = message.split(" ")[1];
            try {
                numberQuestions = Integer.parseInt(arg);
            } catch (NumberFormatException nfe) {
                return "["+nameCB+"] " + "Je ne sais pas quoi faire avec " + arg + "?";
            }
        }
        String url = "https://opentdb.com/api.php";
        JSONObject json = null;
        try {
            for (int i = 1 ; i <= numberQuestions ; i++){
                json = JsonReader.readJsonFromUrl(url + "?amount=" + numberQuestions);
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "[system] Unable to access to " + url;
        } catch (JSONException e) {
            e.printStackTrace();
            return "[system] Error during json parsing " + url;
        }
        playQuiz(json);
        return "["+nameCB+"] Quiz terminé!";
    }

    private void playQuiz(JSONObject jsonQuiz){
        Scanner sc = new Scanner(System.in);
        int nbGoodAnswers = 0;
        String correctAnswer;
        String question;
        String userArg;
        int userAnswer = 0;
        ArrayList<String> badAnswers = new ArrayList<String>();
        ArrayList<String> answers = new ArrayList<String>();
        try {
            JSONArray jsonArray = jsonQuiz.getJSONArray("results");
            for (int i = 0 ; i < jsonArray.length() ; i++){
                JSONObject resultJsonObject = jsonArray.getJSONObject(i);
                JSONArray badAnswersArray = resultJsonObject.getJSONArray("incorrect_answers");
                for (int j = 0 ; j < badAnswersArray.length() ; j++){
                    badAnswers.add(badAnswersArray.getString(j));
                }
                correctAnswer = resultJsonObject.getString("correct_answer");
                question = resultJsonObject.getString("question");
                answers.addAll(badAnswers);
                answers.add(correctAnswer);
                Collections.shuffle(answers);
                System.out.println("["+nameCB+"] Question " + (i+1) + " : " + question);
                for (int k = 0 ; k < answers.size() ; k++){
                    System.out.println("    " + k + "- " + answers.get(k));
                }
                userArg = sc.nextLine();
                if(userArg.equals("@stop"))
                    return;
                try {
                    userAnswer = Integer.parseInt(userArg);
                } catch (NumberFormatException nfe) {
                    System.out.println(userArg + " n'est pas un argument valide.");
                }
                if (answers.get(userAnswer).equals(correctAnswer)){
                    nbGoodAnswers++;
                    System.out.println("Bonne réponse!");
                }else {
                    System.out.println("Mauvaise réponse! La bonne réponse était: " + correctAnswer);
                }
            }
            System.out.println("["+nameCB+"] Score final: " + ((float)nbGoodAnswers/(float)jsonArray.length())*100 + "% de bonnes réponses (" + nbGoodAnswers + "/" + jsonArray.length() + ")");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
