package chatbot;

import org.json.JSONException;
import org.json.JSONObject;
import utils.JsonReader;

import java.io.IOException;

public class IcndbCB extends ChatBot{

    public IcndbCB(ChatBotType chatBotType) {
        this.chatBotType = chatBotType;
        this.nameCB = chatBotType.name();
    }

    @Override
    public String answerTo(String message) {
        String answer = "";
        String joke = "";
        JSONObject json = null;
        String arg = "";
        int numberFacts = 1;
        if (message.split(" ").length > 1){
            arg = message.split(" ")[1];
            try {
                numberFacts = Integer.parseInt(arg);
            } catch (NumberFormatException nfe) {
                return "["+nameCB+"] " + "Je ne sais pas quoi faire avec " + arg + "?";
            }
        }
        String url = "http://api.icndb.com/jokes/random";
        try {
            for (int i = 0 ; i < numberFacts ; i++){
                json = JsonReader.readJsonFromUrl("http://api.icndb.com/jokes/random");
                JSONObject valueJsonObject = json.getJSONObject("value");
                joke = valueJsonObject.getString("joke");
                answer += "["+nameCB+"] " + joke;
                if (i+1 != numberFacts){
                    answer += "\n";
                }
            }
        } catch (IOException e) {
            e.printStackTrace();
            return "[system] Unable to access to " + url;
        } catch (JSONException e) {
            e.printStackTrace();
            return "[system] Error during json parsing " + url;
        }
        return answer;
    }
}
