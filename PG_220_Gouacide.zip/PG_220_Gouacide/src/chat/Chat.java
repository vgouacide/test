package chat;

import chatbot.ChatBot;
import chatbot.ChatBotList;

import java.util.*;

public class Chat {

    private static final ArrayList<String> availableOptions = new ArrayList<String>(Arrays.asList("-p"));
    private static String nameUser = "Anonymous";

    public static String getNameUser() {
        return nameUser;
    }

    public static void main(String[] args) {
        Map<String, String> params = null;
        try {
            params = parseParams(args);
        } catch (IllegalArgumentException e) {
            System.err.println(e.getMessage());
        }

        if (params != null){
            if (params.containsKey("-p")){
                nameUser = params.get("-p");
            }
        }
        String message;
        String[] messageSplitted;
        ChatBotList chatBotList = ChatBotList.getInstance();
        ChatBot chatBot = null;

        Scanner sc = new Scanner(System.in);

        // Main loop for chatting
        while (true){
            System.out.print("[" + nameUser + "] ");
            message = sc.nextLine();
            messageSplitted = message.split(" ");
            if (messageSplitted[0].startsWith("@")){
                chatBot = chatBotList.findChatBotWithType(messageSplitted[0].substring(1));
                if (chatBot != null){
                    System.out.println(chatBot.answerTo(message));
                }else{
                    System.out.println("[system] Je ne connais pas le chatbot " + messageSplitted[0]);
                }
            }
            if(message.equals("++")){
                break;
            }
        }
    }

    /**
     * Parse all parameters given to the program with available options
     * @param args arguments given to the main function
     * @return Map containing for each option an argument
     */
    private static Map<String,String> parseParams(String[] args){
        Map<String, String> params = new HashMap<>();
        boolean optionFound = false;
        for (int i = 0; i < args.length; i++) {
            for(String avaibleOption : availableOptions){
                if(avaibleOption.equals(args[i])){
                    if (!(i+1 < args.length))
                        throw new IllegalArgumentException("No argument for option " + args[i]);
                    params.put(args[i],args[i+1]);
                    optionFound = true;
                }
            }
            if(!optionFound){
                if (args.length > 0){
                    throw new IllegalArgumentException(args[i] + " is not a valid option, list of options :" + availableOptions);
                }
            }
        }
        return params;
    }
}
